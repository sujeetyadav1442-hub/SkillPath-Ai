import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import App from './App.jsx';
import {Toaster} from 'react-hot-toast';
import { BrowserRouter } from 'react-router-dom';
import ThemeProvider from './Context/ThemeProvider.jsx';
import AuthProvider from './Context/AuthProvider.jsx';
createRoot(document.getElementById('root')).render(
  
  <StrictMode>
    <BrowserRouter>
    <ThemeProvider>
      <AuthProvider>
        <App/>
        <Toaster position='top-right'/>
      </AuthProvider>
    </ThemeProvider>
    </BrowserRouter>
  </StrictMode>,
)
